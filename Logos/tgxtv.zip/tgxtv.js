﻿/*
 *  tGX plugin for Movian Media Center
 *
 *  Copyright (C) 2017-2021 dean
 */


(function(plugin) {
    var PREFIX		= 'tgxtv';
	var logo		= plugin.path + "logo.png";
	var logo_srch	= plugin.path + "search.png";
	var categories	= "";
	var search_order= "&sort=id&order=desc";

	var genres = [
		["Bollywood",   "c46=1", 		"hd-movies.gif"],
		["Cam/ts",     "c45=1", 		"hd-movies.gif"],
		//["Cam/ts",     "cMovies=1", 		"hd-movies.gif"],
		
		["Movie Packs", "c4=1", 		"4k-movies.svg"],
		["TV Packs", "c6=1", 		"hd-series.gif"],
		["4K Movies",          "c3=1", 		"hd-movies.gif"],
		["4K Series",	"c11=1",		"hd-series.gif"],
		["HD Series",	"c41=1",		"hd-series.gif"],
		["SD Series",	"c5=1", 		"sd-series.gif"],
		["All Series",	"c41=1&c5=1&c6=1",	"sd-series.gif"],
		["HD Movies",	"c42=1", 		"hd-movies.gif"],
		["SD Movies",	"c1=1&c4=1", 	"sd-movies.gif"],
		["4K Movies",	"c3=1",			"4k-movies.svg"],
		["Animation",	"c28=1", 		"animation.gif"],
		["HD Concerts",	"c25=1", 		"hd-concerts.gif"],
		["Music",		"c22=1",		"music.gif"],
		["Sports",		"c7=1",			"hd-sports.gif"],
		["Documentaries","c9=1", 		"documentaries.gif"],
		
		["TV Packs","c6=1", 		"hd-series.gif"],
	];


    function setPageHeader(page, title, icon) 
	{
		page.type = "directory";
		page.contents = "items";
		page.metadata.logo = (icon?plugin.path+icon:logo);
		page.metadata.icon = (icon?plugin.path+icon:logo);
		page.metadata.title = new showtime.RichText(title);
		page.metadata.background = plugin.path + "bg.jpg";
    }

    var blue = '6699CC', orange = 'FFA500', red = 'EE0000', green = '008B45', white = 'FFFFFF';

	function coloredStr(str, color, size) {
		return '<font '+(size?'size="'+size+'" ':'')+'color="' + color + '">' + str + '</font>';
	}

    var service = plugin.createService(plugin.getDescriptor().title, plugin.getDescriptor().id + ":start", "video", true, logo);

    var settings = plugin.createSettings(plugin.getDescriptor().id, logo, plugin.getDescriptor().title);

    settings.createMultiOpt('baseURL', 'Server Mirror', [
	        ['https://torrentgalaxy.su/', 'torrentgalaxy.su'],
	        ['https://torrentgalaxy.mx/', 'torrentgalaxy.mx'],
			['https://tgx.rs/', 'tgx.rs', true],
	        ['https://torrentgalaxy.to/', 'torrentgalaxy.to']
        ], function(v) {
        service.baseURL = v;
    });

    settings.createBool('caching', 'Cache Server Responses', true, function(v) {
        service.caching = v;
    });

    settings.createMultiOpt('results', 'Number of Search Results', [
	        [50, 50, true],
	        [100, 100]
        ], function(v) {
        service.results = v;
    });


	function search(page, query, count)
	{

		if(query.indexOf(".NF.")==0 || query.indexOf(".AMZN.")==0 || query.indexOf(".HULU.")==0)
	        browseItems(page, "search="+query.replace(/\s/g, "+")+"&"+categories+"sort=2&field=descr", count);
		else
	        browseItems(page, "search="+query.replace(/\s/g, "+")+"&sort=2", count);
	}

	function addOpt(page, item)
	{
		item.addOptURL("Search for '" + item.title + "'", PREFIX + ':search:'+item.title, "search");
		item.addOptURL("Zamunda", 'zamunda:search:'+item.title, "search");
		item.addOptURL("ArenaBG", 'arenabg:search:'+item.title, "search");
		item.addOptURL("Zelka", 'zelka:search:'+item.title, "search");
		item.addOptURL("YTS", 'yts.re:search:'+item.title, "search");
		item.addOptURL("ezTV", 'eztv:search:'+item.title, "search");
		item.addOptURL("Everywhere", 'search:'+item.title, "search");
	}


    function browseItems(page, query, count) 
	{
		page.loading = true;
        var offset = 0;
		var found = 0;
		var c_page = 0;
		var skipped = 0;
		var	cat=categories;
		var doc=null;
		var date=0;
		var is_search = (query.substr(0, 6)=="search");
		if(query!="latest" && query.length) 
		{
			if(is_search && query.indexOf("field=desc")<0)
				cat+=query;
			else
				cat=query;
		}

		var re		= /hovercoverimg\\\' src=\\\'([\S\s]*?)\\\'[\s\S]*?torrents\.php\?cat=([\d]+)"[\s\S]*?<small>([\S\s]*?)<\/small>[\s\S]*?title="([\s\S]*?)"[\s\S]*?href="\/torrent\/([\d]+)\/[\s\S]*?a href='(http[\s\S]*?)'[\s\S]*?(magnet:[\s\S]*?)"[\s\S]*?'border-radius:4px;'>([\s\S]*?)<[\s\S]*?Leechers[\s\S]*?<b>([\d]+)<\/b>[\s\S]*?<b>([\d]+)<\/b>[\s\S]*?text-align:right'>([\S\s]*?)<\/div>/g;

        function appendItems() 
		{
			var url='';
			var icon='';
			var genre='';
			var title='';
			var descr='';
			var title_base='';
			var tagline='';
			var year=null;
			var season=0;
			var episode=0;
			var backdrp = [];
			var item;
			var dur=0;

			var match = re.exec(doc);

			if(match==null) return false;

            while (match) 
			{
				found++;
				url=match[6];
				icon=match[1];

/*
1 image
2 cat-id
3 cat-name
4 title
5 url-id
6 torrent
7 magnet
8 size
9 seed
10 peer
11 date
*/
				seeder=match[9].trim();
				leecher=match[10].trim();
				genre=match[3].replace("&nbsp", "")+"\nAdded: "+coloredStr(match[11], white)+"<br>"+coloredStr("Size: ", orange)+coloredStr(match[8], white)+"<br>"+coloredStr("Peers: ", orange)+coloredStr(seeder+"/"+leecher, white);
				ctitle="Peers: "+seeder+"/"+leecher+" ("+match[8]+")";
				title=match[4].replace(/\./g, " ").replace(/_/g, " ").replace(/<[^>]*>/g, '').replace(/\s\s/g, " ").replace("[TGx]", "");
				tagline=title;
				descr=title;

				if(icon.indexOf("http")<0) icon = service.baseURL + icon;

				dur=0;
				backdrp = [];
				title_base="";
				year=null;
				season=0;
				episode=0;


				var is_series=title.match(/([\s\S]*?)[\.|\s][S|s]([\d][\d])[E|e]([\d][\d])[\S\s]*?(480[p|i]|576[p|i]|720[p|i]|1080[p|i]|2160[p|i]|UHD|FHD|4K|3D|HDTV|HDCAM|DVB|DVD|HBO|HDRip|PAL|NTSC|DVDRip|BRRip|BDRip|BluRay|Blu-Ray|BDRemux|WEB|XviD|AVC|HEVC|AMZN|NF|DSNP|HULU|MP4|[x|h]264|[x|h]265)/i);
				if(is_series) // S00E00 -> 00x00
				{
					title=is_series[1]+" "+is_series[2]+"x"+is_series[3]+coloredStr(" ("+is_series[4]+")", 'A0A0A0', "+2");
					title_base=is_series[1].trim();
					season=parseInt(is_series[2]);
					episode=parseInt(is_series[3]);
				}
				else
				{
					is_series=descr.match(/([\s\S]*?)[\.|\s][S|s]([\d][\d])[E|e]([\d][\d])/i);
					if(!is_series) is_series=title.match(/([\s\S]*?)[\.|\s][S|s]([\d][\d])[E|e]([\d][\d])/i);
					if(!is_series) is_series=descr.match(/([\s\S]*?)[\.|\s]([\d][\d])[x|X]([\d][\d])/i);
					if(!is_series) is_series=title.match(/([\s\S]*?)[\.|\s]([\d][\d])[x|X]([\d][\d])/i);
					if(is_series) // S00E00 -> 00x00
					{
						title=is_series[1]+" "+is_series[2]+"x"+is_series[3];
						title_base=is_series[1].trim();
						season=parseInt(is_series[2]);
						episode=parseInt(is_series[3]);
					}
					else
					{
						is_series=title.match(/([\s\S]*?)[\.|\s][S|s]([\d][\d])[\S\s]*?(480[p|i]|576[p|i]|720[p|i]|1080[p|i]|2160[p|i]|UHD|FHD|4K|3D|HDTV|HDCAM|DVB|DVD|HBO|HDRip|PAL|NTSC|DVDRip|BRRip|BDRip|BluRay|Blu-Ray|BDRemux|WEB|XviD|AVC|HEVC|AMZN|NF|DSNP|HULU|MP4|[x|h]264|[x|h]265)/i);
						if(!is_series) is_series=title.match(/([\s\S]*?)[\.|\s]Season[\s]([\d][\d])[\S\s]*?(480[p|i]|576[p|i]|720[p|i]|1080[p|i]|2160[p|i]|UHD|FHD|4K|3D|HDTV|HDCAM|DVB|DVD|HBO|HDRip|PAL|NTSC|DVDRip|BRRip|BDRip|BluRay|Blu-Ray|BDRemux|WEB|XviD|AVC|HEVC|AMZN|NF|DSNP|HULU|MP4|[x|h]264|[x|h]265)/i);
						if(!is_series) is_series=title.match(/([\s\S]*?)[\.|\s]Season[\s]([\d])[\S\s]*?(480[p|i]|576[p|i]|720[p|i]|1080[p|i]|2160[p|i]|UHD|FHD|4K|3D|HDTV|HDCAM|DVB|DVD|HBO|HDRip|PAL|NTSC|DVDRip|BRRip|BDRip|BluRay|Blu-Ray|BDRemux|WEB|XviD|AVC|HEVC|AMZN|NF|DSNP|HULU|MP4|[x|h]264|[x|h]265)/i);
						if(!is_series) is_series=title.match(/([\s\S]*?)[\.|\s]Season[\s]([\d][\d])/i);
						if(!is_series) is_series=title.match(/([\s\S]*?)[\.|\s]Season[\s]([\d])/i);
						if(is_series)
						{
							if(is_series[3])
								title=is_series[1]+" - Season "+parseInt(is_series[2])+" "+coloredStr(" ("+is_series[3]+")", 'A0A0A0', "+2");
							else
								title=is_series[1]+" - Season "+parseInt(is_series[2]);
							title_base=is_series[1].trim();
							season=parseInt(is_series[2]);
							episode=99;
						}
						else // YYYY
						{
							is_series=title.match(/([\s\S]*?)[\.|\s|\(]([\d]{4})[^p^i][\.\s\S]*?(480[p|i]|576[p|i]|720[p|i]|1080[p|i]|2160[p|i]|UHD|FHD|4K|3D|HDTV|HDCAM|DVB|DVD|HBO|HDRip|PAL|NTSC|DVDRip|BRRip|BDRip|BluRay|Blu-Ray|BDRemux|WEB|XviD|AVC|HEVC|AMZN|NF|DSNP|HULU|MP4|[x|h]264|[x|h]265)[\.\s]*?(480[p|i]|576[p|i]|720[p|i]|1080[p|i]|2160[p|i]|UHD|FHD|4K|3D|HDTV|HDCAM|DVB|DVD|HBO|HDRip|PAL|NTSC|DVDRip|BRRip|BDRip|BluRay|Blu-Ray|BDRemux|WEB|XviD|AVC|HEVC|AMZN|NF|DSNP|HULU|MP4|[x|h]264|[x|h]265)/i);
							if(is_series)
							{
								title=is_series[1]+coloredStr(" ("+is_series[3]+" "+is_series[4]+")", 'A0A0A0', "+2");
								title_base=is_series[1].trim();
								year=parseInt(is_series[2]);
							}
							else
							{
								is_series=descr.match(/([\s\S]*?)[\:|\/|\.|\(|\?|\-|\–]/i);
								if(!is_series) is_series=title.match(/([\s\S]*?)[\:|\/|\.|\(|\?|\-|\–]/i);
								if(is_series)
								{
									title=descr;
									title_base=is_series[1].trim();
								}
							}
						}
					}
				}

				title = title.replace(/[\d]{4}\s/, "");
				title_base = title_base.replace(/\s[\d]{4}/, "");

				descr = descr.trim();

				descr+="<hr>";
				if(title_base=="") title_base=title;

				item=null;

				title_base2 = title_base;
				if(season>0)
				{
					if(episode>0 && episode<99)
						title_base2 += " - "+season+"x"+(episode<10?"0":"")+episode;
					else
						title_base2 += " - Season "+season;
				}
				else
					if(year>1900 && year<2030)
					{
						title_base2 += " ("+year+")";
					}

				if(tagline.indexOf("265")>0)
					title+=coloredStr("  (x265) ", 'AAAAAA', "+2");

				if(year>1900 && year<2030)
				{
					title+=coloredStr("  ("+year+") ", 'AAAAAA', "+2");
				}
		
				item = page.appendItem('torrent:browse:'+url, 
					"video", {
						icon: icon,
						backdrops: [ 
							{url: backdrp[1]}, {url: backdrp[2]}, 
							{url: backdrp[3]}, {url: backdrp[4]}
						],

						title: new showtime.RichText(title),
						tagline: tagline,
						year: year,
						ctitle: new showtime.RichText(coloredStr(ctitle, 'AAAAAA', 2)),
						description: new showtime.RichText(coloredStr(genre+(year>1900?coloredStr("\nYear: ", orange)+year:""), orange)),
					});

				item.date=date;

				if(title_base.length>2)
				{
					item.title=title_base;

					addOpt(page, item);
				}

				offset++;
				page.entries++;
				if(page.entries>10) page.loading = false;
				match = re.exec(doc);
				if(offset>=count) {return false;}

            }
			return true;
        }

        function loader() 
		{
			if(offset>=count) return false;
			ret = true;
			var c_page2=c_page+1;

			if(is_search) c_page2=c_page+1+(parseInt(service.results)+50)/50;

            page.loading = true;
			for (var i = c_page; i < (c_page2); i++) 
			{
				last_offset = offset;

				doc = showtime.httpReq(service.baseURL+"torrents.php?lang=0&nox=2&"+cat+"&page="+i+search_order, {
				//doc = showtime.httpReq(service.baseURL+"torrents.php?page="+i+search_order, {
						headers: {'User-Agent': "Mozilla/5.0 (Windows NT 6.1; rv:50.0) Gecko/20100101 Firefox/50.0"},
						caching: service.caching,
						compression: true,
						cacheTime: (service.caching==true?3600:0),
					}).toString();

				appendItems();
				c_page++;

				if( (offset == last_offset) ) ret = false;
				if( query!="latest" && found<20 ) ret = false;

				if(offset>=count) ret = false;
				if(!ret) {offset = count+1; break;}
			}

			page.loading = false;
			return ret;
		}

		loader();
		page.paginator = loader;

        page.loading = false;
    }

	plugin.addURI(PREFIX + ":genre:(.*)", function(page, genre) {
		setPageHeader(page, genres[genre][0], genres[genre][2]);
		page.flush();
		page.metadata.glwview =  plugin.path + "list.view";
		page.options.createMultiOpt('order', 'Order by', [
			['&sort=id&order=desc',		      'Date', true],
			['&sort=seeders&order=desc',      'Peers'],
			], function(order) {
				if(search_order!=order)
				{
					search_order = order;
					page.redirect(PREFIX + ":genre:"+genre);
				}
			}, true);
		browseItems(page, genres[genre][1], 1200);
	});

    plugin.addURI(PREFIX + ":search:(.*)", function(page, title) {
		var icon=null;
		var title2=title;

		if(title==".NF.")	{title2="Netflix"; icon="netflix.png";}
		if(title==".AMZN.") {title2="Amazon"; icon="amazon.png";}
		if(title==".HULU.") {title2="Hulu"; icon="hulu.png";}

        setPageHeader(page, "Results for '"+title2+"':", icon);
		page.metadata.glwview =  plugin.path + "list.view";

		page.options.createMultiOpt('order', 'Order by', [
			['&sort=id&order=desc',		      'Date'],
			['&sort=seeders&order=desc',      'Peers', true],
			], function(order) {
				if(search_order!=order)
				{
					search_order = order;
					page.redirect(PREFIX + ":search:"+title);
				}
			}, true);
		search(page, title, 1200);
    });

    plugin.addURI(PREFIX + ":genres", function(page) {
        setPageHeader(page, 'Categories');
		page.flush();
        for(var i in genres) 
		{
            page.appendItem(PREFIX + ":genre:" + i, "directory", {
				title: genres[i][0],
				icon: plugin.path + genres[i][2]
            });
        }

		page.appendItem(PREFIX + ":search:.HULU.", "directory", {
			title: "Hulu",
			icon: plugin.path + "hulu.png"
		});

		page.appendItem(PREFIX + ":search:.AMZN.", "directory", {
			title: "Amazon",
			icon: plugin.path + "amazon.png"
		});

		page.appendItem(PREFIX + ":search:.NF.", "directory", {
			title: "Netflix",
			icon: plugin.path + "netflix.png"
		});

    });

    plugin.addURI(PREFIX + ":latest", function(page) {
        setPageHeader(page, 'Latest');
		page.flush();
		page.metadata.glwview =  plugin.path + "list.view";
        browseItems(page, "latest", 1200);
    });

    function processStartPage(page) 
	{
		page.appendItem(PREFIX + ":search:", 'search', {
			title: 'Search'
		});

        page.appendItem(PREFIX + ":genres", "directory", {
			icon: logo,
            title: 'Categories'
        });

        page.appendItem("", "separator", {
			title: new showtime.RichText(coloredStr('Latest', orange, "+2"))
        });
        browseItems(page, "latest", 10);
        page.appendItem(PREFIX + ':latest', 'directory', {
			icon: logo,
            title: 'More... ►'
        });

        page.loading = false;
    }


    // Start page
    plugin.addURI(plugin.getDescriptor().id + ":start", function(page) 
	{
		page.metadata.glwview =  plugin.path + "list.view";

        setPageHeader(page, plugin.getDescriptor().title);

		page.entries = 0;
		page.loading = true;

        page.options.createAction('update', "Update tGX", function() 
		{
			showtime.notify("Updating, please wait...", 5);
			page.redirect('http://api2.deanbg.com/tgx.zip');
        });

		page.options.createMultiOpt('order', 'Order by', [
			['&sort=id&order=desc',		      'Date', true],
			['&sort=seeders&order=desc',      'Peers'],
			], function(order) {
				if(search_order!=order)
				{
					search_order = order;
					page.redirect(PREFIX + ":start");
				}
			}, true);

		categories="";
        for(var i in genres) 
			categories+=genres[i][1]+"&";

        processStartPage(page);

		page.loading = false;

    });

    plugin.addSearcher(plugin.getDescriptor().title, logo, function(page, query) 
	{
		search(page, query, service.results);
    });

}) (this);
