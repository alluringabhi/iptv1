
var page = require('showtime/page');
var service = require('showtime/service');
var settings = require('showtime/settings');
var http = require('showtime/http');
var string = require('native/string');
var plugin = JSON.parse(Plugin.manifest);
var logo = Plugin.path + plugin.icon;
var io = require('native/io');
var popup = require('native/popup');
var BG = Plugin.path + "bg1.png";
var store = require('movian/store');
var crypto = require('native/crypto');
var tos = 'The developer has no affiliation with the sites what so ever.\n\n';
tos += 'Before you proceed Set username and password in settings then come here again\n\n';
tos += 'To accept this permanent set it to "ON" in settings.\n';
tos += 'Are you done with setup and want to proceed? If Yes Click Login on top\n';
var error = 'Error Occured Please Login \n';
error += 'Check username & password in settings be sure to use +91 \n';
error += 'if problem persist check internet connection. \n';

var credentials = store.create('credentials');
if (!credentials.sso1) credentials.sso1 = '';
if (!credentials.unid1) credentials.unid1 = '';
if (!credentials.devid) credentials.devid = '';

     function uniqueID(){
        function chr4(){
              return Math.random().toString(16).slice(-4);
            }
            return chr4() + chr4() +
              '-' + chr4() +
              '-' + chr4() +
              '-' + chr4() +
              '-' + chr4() + chr4() + chr4();
          }
credentials.devid = uniqueID();       

UA = 'Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/JioTV/537.36 (KAIOS, like Gecko) Chrome/63.0.3239.84 Safari/537.36 ExoPlayer'

RichText = function(x) {
    this.str = x.toString();
}

RichText.prototype.toRichString = function(x) {
    return this.str;
}

var blue = '6699CC', orange = 'FFA500', red = 'EE0000', green = '008B45';

function coloredStr(str, color) {
    return '<font color="' + color + '">' + str + '</font>';
}

function setPageHeader(page, title) {
    if (page.metadata) {
        page.metadata.title = title;
        page.metadata.logo = logo;
        page.metadata.background = BG;
		page.metadata.backgroundAlpha = 0.25;
		page.metadata.backgroundAvailable = true;
    }
    page.type = "directory";
    page.contents = "items";
    page.entries = 0;
    page.loading = true;
}

var category = [
    "Entertainment","Movies","Kids" ,"Sports" ,"Infotainment", "News", 'Buisness News',	
    "Devotional","Jio Darshan",	"Music"	,"Shopping", "Regional"];

var language = [
        "Hindi",  "English","Marathi","Punjabi","Urdu","Bengali", "Malayalam", 
		"Tamil","Gujarati", "Odia", "Telugu", "Bhojpuri", "Kannada", "Assamese", "Nepali", "French"];

var group = [ "Entertainment","Movies","News","Infotainment","Kids","Sports","Devotional","Music","Educational", 
         "English Entertainment","English Movies","English Infotainment","English Kids","English Sports",
         "English Devotional","English Music","English Educational","English News",
         "Assamese","Bengali","Bhojpuri","Gujarati","Kannada","Malayalam",
         "Marathi","Nepali","Odia","Punjabi","Tamil","Telugu","Urdu","French"];

service.create(plugin.title, plugin.id + ":start", 'tv', true, logo);
settings.globalSettings(plugin.id, plugin.title, logo, plugin.synopsis);
settings.createString('username', "Jio Username or use +91 if logging from mobile number", '+91', function(v) {
service.username = v;
});
settings.createString('password', "JIO Password", '', function(v) {
service.password = v;
});
settings.createString('accesskey', "Accesskey", 'abhinav', function(v) {
    service.key = v;
    });

settings.createMultiOpt('baseURL', 'Server Mirror', [
  ['https://japi.alluringabhi.repl.co/jioapi.php', 'REPL',true],
    //['https://japi..repl.co/', 'Server2'],
    ['http://jtad.coolpage.biz/j1/jioapi.php','Private host', ]  
], function(v) {
service.baseUrl = v;
});
settings.createBool('caching', 'Cache Server Responses', false, function(v) {
    service.caching = v;
});
settings.createBool('debug', 'Development Mode',  true, function(v) {
    service.debug = v;
});
settings.createBool("tosaccepted", "Accepted TOS (available in opening the plugin)", true, function (v) {
    service.tosaccepted = v;
});

io.httpInspectorCreate('https://tv.media.jio.com/streams_live/.*', function(ctrl) {  
ctrl.setHeader('Host',' tv.media.jio.com');
ctrl.setHeader('langId',' 6');
ctrl.setHeader('User-Agent',UA);  
ctrl.setHeader('lbcookie',' 1');
ctrl.setHeader('devicetype',' phone');
ctrl.setHeader('channelid',' 173');
ctrl.setHeader('uniqueid',credentials.unid1);
ctrl.setHeader('appversion',' 3.5.1');
ctrl.setHeader('ssotoken',credentials.sso1);
ctrl.setHeader('os',' ios');
ctrl.setHeader('srno',' 220222173045');
ctrl.setHeader('versioncode',' 324');
ctrl.setHeader('isott',' false');
ctrl.setHeader('deviceid',credentials.devid);
ctrl.setHeader('Connection',' keep-alive');
ctrl.setHeader('usergroup',' tvYR7NSNn7rymo3F');
ctrl.setHeader('appversioncode',' 324');
ctrl.setHeader('Accept-Language',' en-IN,en-GB;q=0.9,en;q=0.8');
ctrl.setHeader('Accept',' */*');  
ctrl.setHeader('Accept-Encoding',' identity');  
  return 0;
});


io.httpInspectorCreate("https.*jiotv.live.cdn.jio.com.*.m3u8", function (ctrl) {
    ctrl.setHeader('Content-Type', 'application/x-mpegURL');
    ctrl.setHeader('User-Agent', UA);
   // ctrl.setHeader('Authorization', '"Bearer" + jiotvjct()')
    return 0;
});

function getsso1(){
    if (!service.password){
        page.error('Set Username and password');

    } else 

    {
   try {
    
    var auth = JSON.parse(http.request('https://api.jio.com/v3/dip/user/unpw/verify', {
    method: "POST",
    //debug: service.debug,
    headers: {
        'User-Agent': UA,
        'x-api-key': 'l7xx75e822925f184370b2e25170c5d5820a',
        'Content-Type':'application/json'
        //'app-name': 'RJIL_JioTVPlus',
        //'x-api-key': 'l7xx61fae40fe3af4c93b02792ae12422a82',
        //appkey': '06758e99be484fca56fb'
        },
        //cacheTime: (service.caching==true?43200:0),
        postdata:  JSON.stringify({"identifier":''+(service.username)+'',"password":''+(service.password)+'',"rememberUser":"T","upgradeAuth":"Y","returnSessionDetails":"T","deviceInfo":{"consumptionDeviceName":"Jio","info":{"type":"android","platform":{"name":"vbox86p","version":"8.0.0"},"androidId":"6fcadeb7b4b10d77"}}}) 
            
    
    }));        
        }
        catch(err) {
            page.error('Seems API is down');
           
        }
       
        credentials.sso1 = auth.ssoToken;
        credentials.unid1 = auth.sessionAttributes.user.unique;
        
    }}

    jctBase = "cutibeau2ic";
    function hex2a(hexx) {
        var hex = hexx.toString();//force conversion
        var str = '';
        for (var i = 0; i < hex.length; i += 2)
            str += String.fromCharCode(parseInt(hex.substr(i, 2), 16));
        return str;
        }
    var MD5 = function(d){var r = M(V(Y(X(d),8*d.length)));return r.toLowerCase()};function M(d){for(var _,m="0123456789ABCDEF",f="",r=0;r<d.length;r++)_=d.charCodeAt(r),f+=m.charAt(_>>>4&15)+m.charAt(15&_);return f}function X(d){for(var _=Array(d.length>>2),m=0;m<_.length;m++)_[m]=0;for(m=0;m<8*d.length;m+=8)_[m>>5]|=(255&d.charCodeAt(m/8))<<m%32;return _}function V(d){for(var _="",m=0;m<32*d.length;m+=8)_+=String.fromCharCode(d[m>>5]>>>m%32&255);return _}function Y(d,_){d[_>>5]|=128<<_%32,d[14+(_+64>>>9<<4)]=_;for(var m=1732584193,f=-271733879,r=-1732584194,i=271733878,n=0;n<d.length;n+=16){var h=m,t=f,g=r,e=i;f=md5_ii(f=md5_ii(f=md5_ii(f=md5_ii(f=md5_hh(f=md5_hh(f=md5_hh(f=md5_hh(f=md5_gg(f=md5_gg(f=md5_gg(f=md5_gg(f=md5_ff(f=md5_ff(f=md5_ff(f=md5_ff(f,r=md5_ff(r,i=md5_ff(i,m=md5_ff(m,f,r,i,d[n+0],7,-680876936),f,r,d[n+1],12,-389564586),m,f,d[n+2],17,606105819),i,m,d[n+3],22,-1044525330),r=md5_ff(r,i=md5_ff(i,m=md5_ff(m,f,r,i,d[n+4],7,-176418897),f,r,d[n+5],12,1200080426),m,f,d[n+6],17,-1473231341),i,m,d[n+7],22,-45705983),r=md5_ff(r,i=md5_ff(i,m=md5_ff(m,f,r,i,d[n+8],7,1770035416),f,r,d[n+9],12,-1958414417),m,f,d[n+10],17,-42063),i,m,d[n+11],22,-1990404162),r=md5_ff(r,i=md5_ff(i,m=md5_ff(m,f,r,i,d[n+12],7,1804603682),f,r,d[n+13],12,-40341101),m,f,d[n+14],17,-1502002290),i,m,d[n+15],22,1236535329),r=md5_gg(r,i=md5_gg(i,m=md5_gg(m,f,r,i,d[n+1],5,-165796510),f,r,d[n+6],9,-1069501632),m,f,d[n+11],14,643717713),i,m,d[n+0],20,-373897302),r=md5_gg(r,i=md5_gg(i,m=md5_gg(m,f,r,i,d[n+5],5,-701558691),f,r,d[n+10],9,38016083),m,f,d[n+15],14,-660478335),i,m,d[n+4],20,-405537848),r=md5_gg(r,i=md5_gg(i,m=md5_gg(m,f,r,i,d[n+9],5,568446438),f,r,d[n+14],9,-1019803690),m,f,d[n+3],14,-187363961),i,m,d[n+8],20,1163531501),r=md5_gg(r,i=md5_gg(i,m=md5_gg(m,f,r,i,d[n+13],5,-1444681467),f,r,d[n+2],9,-51403784),m,f,d[n+7],14,1735328473),i,m,d[n+12],20,-1926607734),r=md5_hh(r,i=md5_hh(i,m=md5_hh(m,f,r,i,d[n+5],4,-378558),f,r,d[n+8],11,-2022574463),m,f,d[n+11],16,1839030562),i,m,d[n+14],23,-35309556),r=md5_hh(r,i=md5_hh(i,m=md5_hh(m,f,r,i,d[n+1],4,-1530992060),f,r,d[n+4],11,1272893353),m,f,d[n+7],16,-155497632),i,m,d[n+10],23,-1094730640),r=md5_hh(r,i=md5_hh(i,m=md5_hh(m,f,r,i,d[n+13],4,681279174),f,r,d[n+0],11,-358537222),m,f,d[n+3],16,-722521979),i,m,d[n+6],23,76029189),r=md5_hh(r,i=md5_hh(i,m=md5_hh(m,f,r,i,d[n+9],4,-640364487),f,r,d[n+12],11,-421815835),m,f,d[n+15],16,530742520),i,m,d[n+2],23,-995338651),r=md5_ii(r,i=md5_ii(i,m=md5_ii(m,f,r,i,d[n+0],6,-198630844),f,r,d[n+7],10,1126891415),m,f,d[n+14],15,-1416354905),i,m,d[n+5],21,-57434055),r=md5_ii(r,i=md5_ii(i,m=md5_ii(m,f,r,i,d[n+12],6,1700485571),f,r,d[n+3],10,-1894986606),m,f,d[n+10],15,-1051523),i,m,d[n+1],21,-2054922799),r=md5_ii(r,i=md5_ii(i,m=md5_ii(m,f,r,i,d[n+8],6,1873313359),f,r,d[n+15],10,-30611744),m,f,d[n+6],15,-1560198380),i,m,d[n+13],21,1309151649),r=md5_ii(r,i=md5_ii(i,m=md5_ii(m,f,r,i,d[n+4],6,-145523070),f,r,d[n+11],10,-1120210379),m,f,d[n+2],15,718787259),i,m,d[n+9],21,-343485551),m=safe_add(m,h),f=safe_add(f,t),r=safe_add(r,g),i=safe_add(i,e)}return Array(m,f,r,i)}function md5_cmn(d,_,m,f,r,i){return safe_add(bit_rol(safe_add(safe_add(_,d),safe_add(f,i)),r),m)}function md5_ff(d,_,m,f,r,i,n){return md5_cmn(_&m|~_&f,d,_,r,i,n)}function md5_gg(d,_,m,f,r,i,n){return md5_cmn(_&f|m&~f,d,_,r,i,n)}function md5_hh(d,_,m,f,r,i,n){return md5_cmn(_^m^f,d,_,r,i,n)}function md5_ii(d,_,m,f,r,i,n){return md5_cmn(m^(_|~f),d,_,r,i,n)}function safe_add(d,_){var m=(65535&d)+(65535&_);return(d>>16)+(_>>16)+(m>>16)<<16|65535&m}function bit_rol(d,_){return d<<_|d>>>32-_}
    btoaa = function (data) {
        var ascii = chars.ascii(),
          len = data.length - 1,
          i = -1,
          b64 = '';
      
        while (i < len) {
          var code = data.charCodeAt(++i) << 16 | data.charCodeAt(++i) << 8 | data.charCodeAt(++i);
          b64 += ascii[(code >>> 18) & 63] + ascii[(code >>> 12) & 63] + ascii[(code >>> 6) & 63] + ascii[code & 63];
        }
      
        var pads = data.length % 3;
        if (pads > 0) {
          b64 = b64.slice(0, pads - 3);
      
          while (b64.length % 4 !== 0) {
            b64 += '=';
          }
        }
      
        return b64;
      };
    var chars = {
        ascii: function () {
          return 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/=';
        },
        indices: function () {
          if (!this.cache) {
            this.cache = {};
            var ascii = chars.ascii();
      
            for (var c = 0; c < ascii.length; c++) {
              var chr = ascii[c];
              this.cache[chr] = c;
            }
          }
          return this.cache;
        }
      };
 
  
  var md5digest =function(str) {
    // md5 = MD5(str);
     md5 = MD5(unescape(encodeURIComponent(str)))
     return  hex2a(md5)
   }
   function tokformat(str) {
     var str = btoaa(md5digest(str));
     var str = str.replace("\n",'',str)
     var str = str.replace("\r",'',str)
     var str = str.replace("/",'_',str)
     var str = str.replace("+",'-',str)
     var str = str.replace("=",'',str)
     return str
   }
  function ltrim (str, charlist) {
 
     charlist = !charlist
       ? ' \\s\u00A0'
       : (charlist + '').replace(/([[\]().?/*{}+$^:])/g, '$1')
     const re = new RegExp('^[' + charlist + ']+', 'g')
     return (str + '')
       .replace(re, '')
   }
   function generateJct(st, pxe) {
     var str = ltrim(tokformat(jctBase + st + pxe))
     var str = str.replace("\n",'',str)
     var str = str.replace("\r",'',str)
     var str = str.replace("/",'_',str)
     var str = str.replace("+",'-',str)
     var str = str.replace("=",'',str)
     return str
   }
   function generatePxe() {
    var d = new Date();
     var time = d.getTime()/10000;
       var time = ((time.toFixed(0) + 6000) / 1000) + 1010
     return time
   }
   
   function generateSt() {
     var sso = credentials.sso1
     var str = tokformat(sso)
     var str = str.replace("\n",'',str)
     var str = str.replace("\r",'',str)
     var str = str.replace("/",'_',str)
     var str = str.replace("+",'-',str)
     var str = str.replace("=",'',str)
     return  str
   }
 
   function jiotvjct() {
     var st = generateSt();
     var pxe = generatePxe();
     var jct1 = generateJct(st, pxe);
     var a =  "?jct="+jct1+"&pxe="+pxe+"&st="+st;
    return a
   }


function browseItems(page, query, count) {
   
    var offset = 1;
    page.entries = 0;
    
    function loader() {
        if (!offset) return false;
        page.loading = true;

        var args = {
            limit: 40,
            page: offset,
            key: service.key

        };
        for (var i in query)
            args[i] = unescape(query[i]);

        try {
            
             
            var c = JSON.parse(http.request(service.baseUrl+'/jioapi.php?', {    
            args: args,
            caching: service.caching,
            compression: true,
            headers: { 'User-Agent' : UA, 'Connection': 'keep-alive'},
            cacheTime: (service.caching==true?86400:0) }));
           
        } 
        catch(err) {
            page.error('Seems like API stopped working');
            return;
        }
       
        page.metadata.logo = c.logo;
        page.loading = false;
        if (offset == 1 && page.metadata && c[0].count)
         page.metadata.title;
        for (var i in c) {
            addChannels(page, c[i]);
            if (count && page.entries > count) return offset = false;
        }
        offset++;
        return c && c[0].count > 0;
    }
    loader();
    page.asyncPaginator = loader;
     
    page.loading = false;
}


new page.Route(plugin.id + ":cat:(.*)", function(page, cat) {
    setPageHeader(page, cat);
    browseItems(page, {
        cat: cat
    });
    page.loading = false;
});

new page.Route(plugin.id + ":category", function(page, cat) {
    setPageHeader(page, 'Category');
    for(var i in category) {
        var item = page.appendItem(plugin.id + ":cat:" + category[i], "directory", {
            title: category[i]
        });
    }
    page.loading = false;
});

new page.Route(plugin.id + ":lang:(.*)", function(page, lang) {
    setPageHeader(page, lang);
    browseItems(page, {
        lang: lang
    });
    page.loading = false;
});

new page.Route(plugin.id + ":language", function(page, lang) {
    setPageHeader(page, 'Language');
    for(var i in language) {
        var item = page.appendItem(plugin.id + ":lang:" + language[i], "directory", {
            title: language[i]
        });
    }
    page.loading = false;
});

new page.Route(plugin.id + ":set:(.*)", function(page, set) {
    setPageHeader(page, set);
    browseItems(page, {
        set: set
    });
    page.loading = false;
});

new page.Route(plugin.id + ":group", function(page, set) {
    setPageHeader(page, 'Groups');
    for(var i in group) {
        var item = page.appendItem(plugin.id + ":set:" + group[i], "directory", {
            title: group[i]
        });
    }
    page.loading = false;
});


new page.Route(plugin.id + ":login", function(page) {
    setPageHeader(page, 'Login Page');
    getsso1();
    page.flush();
    popup.notify('Congratulations Successfully logged in to Jiotv', 4);
    page.loading = false;
    page.redirect(plugin.id + ':start');

});
new page.Route(plugin.id + ":logout", function(page) {
    setPageHeader(page, 'Logout Page');
    credentials.sso1 = "";
    credentials.unid1 = "";
    page.flush();
    popup.notify('Logged Out', 4);
    page.loading = false;
    page.redirect(plugin.id + ':start');

});
new page.Route(plugin.id + ":sports", function(page) {
    setPageHeader(page, 'All Sports Channels');
    browseItems(page, {
        cat: 'Sports'
    });
    page.loading = false;
});

function processStartPage(page) {
    
    if (!service.tosaccepted)
    if (popup.message(tos, true, true)) service.tosaccepted = true;

    else {
        page.error("TOS not accepted. plugin disabled");
        return;
    }

    page.appendItem(plugin.id + ":login", "directory", {
        title: 'Login'
    });
    page.appendItem(plugin.id + ":logout", "directory", {
        title: 'Logout'
    });
    page.appendItem(plugin.id + ":category", "directory", {
        title: 'Category'
    });
    page.appendItem(plugin.id + ":language", "directory", {
        title: 'Language'
    });
    page.appendItem(plugin.id + ":group", "directory", {
        title: 'Groups'
    });
    page.appendItem("", "separator", {
        title: 'Sports'
    });
    browseItems(page, {
        cat: 'Sports'
    }, 7);
    page.appendItem(plugin.id + ':sports', 'directory', {
        title: 'More ►'
    });
    page.appendItem("", "separator", {
        title: 'Entertainment'
    });
    browseItems(page, {
        set: 'Entertainment'
    });
    page.loading = false;
}

new page.Route(plugin.id + ":start", function(page) {
    setPageHeader(page, plugin.synopsis);
    //addOptions(page);
    processStartPage(page);
});

new page.Route(plugin.id + ":list:(.*)", function(page, query) {
    setPageHeader(page, 'Filter by: ' + unescape(query));
    browseItems(page, {
        query_term: query
    });
    page.loading = false;
});


function addChannels(page, ch, ch1, ch2) {
    var item = page.appendItem(plugin.id + ':play:'+ encodeURIComponent(ch.name)+':'  + encodeURIComponent(ch.link)+':'  + encodeURIComponent(ch.logo)+':'  + encodeURIComponent(ch.quality), "video", 
    {
        title: new RichText(ch.name + ' ' + coloredStr(ch.language, orange),50 ),
        icon: ch.logo,
        item: item,
        image: ch.logo,
        description: new RichText(
            coloredStr('\nGroup: ', blue) + ch.group +
            coloredStr('\nLanguage: ', orange) + ch.language +
            coloredStr('\nCategory: ', green) + ch.category +
            coloredStr('\ntvg id: ', red) + ch.tvgid +
            coloredStr('\nquality: ', red) + ch.quality
        )
    });
    page.entries++;
}


function getLive (url){
    while(true){
        var res = false;
        var s = { method: "GET",
                   debug: service.debug,
                   headers: { 'User-Agent' : UA, 'Connection': 'keep-alive'},
                   //args: jiotvjct(),
                 noFail:true,
                  noFollow: true,
                };
        try {
            res = http.request(url, s);
        }
        catch(err) {
            page.error('Seems API is down');
            return;
        }
        //if(!res) break;
        if(res.statuscode == 301) {
             if(res.headers.hasOwnProperty('Location')) {
                 url = res.headers['Location'] ;
             }
             if(res.statuscode == 405) {
                url=url.replace(".m3u8",'".m3u8"+jiotvjct()',str)
             }

             else {
                 break;
             }
        }
        if(res.statuscode == 200) {
             return url;
        }
    }
    return res;
}

function getplay1 (url, quality){
 var q = '_'+quality+'.m3u8'

    while(true){
        var res = false;
        var s = { method: "GET",
                   debug: service.debug,
                   headers: { 'User-Agent' : UA, 'Connection': 'keep-alive'},
                   //args: jiotvjct(),
                 noFail:true,
                  noFollow: true,
                };
        try {
            res = http.request(url, s);
        }
        catch(err) {
            page.error('Seems API is down');
            return;
        }
        //if(!res) break;
        if(res.statuscode == 301) {
             if(res.headers.hasOwnProperty('Location')) {
                 url = res.headers['Location'] ;
             }
             if(res.statuscode == 405) {
                url=url.replace(".m3u8",'_1200.m3u8',str)
             }

             else {
                 break;
             }
        }
        if(res.statuscode == 200) {
            url = url.replace(".m3u8",q,url)
             return url;
        }
    }
    return res;
}

function getplay (url) {
    var s = { method: "GET",
                   debug: service.debug,
                   headers: { 'User-Agent' : UA, 'Connection': 'keep-alive'},
                   
                    //noFail:true,
                  noFollow: true,
                };
                url = decodeURIComponent(url)
        var location =   http.request(url, s).headers.Location;
        return location
}



new page.Route(plugin.id + ":play:(.*):(.*):(.*):(.*)", function(page, name, url, logo, quality) {
    if (!credentials.sso1)

    { page.error(error); }

    else {   
    page.loading = false;
    no_subtitle_scan = true;
    page.type = 'video';
    page.source = "videoparams:" + JSON.stringify({
        title: decodeURIComponent(name),
        name:decodeURIComponent(name),
        icon : decodeURIComponent(logo),
        quality : decodeURIComponent(quality),
        canonicalUrl: plugin.id + ':play:' + decodeURIComponent(name) + ':' + getplay(url),
        sources: [{url: "hls:"+ getplay1((getLive(getplay(url)+jiotvjct())),quality), mimetype: 'application/x-mpegURL'}],
        no_subtitle_scan: no_subtitle_scan
    });
}
});
